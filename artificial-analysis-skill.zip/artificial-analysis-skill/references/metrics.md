# Artificial Analysis metric definitions

Read this when the user asks what a metric/eval means, how the Intelligence
Index is composed, or how AA measures cost/speed. All descriptions are from
artificialanalysis.ai (/evaluations/*, /methodology).

## Composite indexes (0–100, higher = better)

- **Intelligence Index (`intelligenceIndex`)** — AA's headline metric. v4.1.1
  combines 9 evals: GDPval-AA v2, τ³-Banking, Terminal-Bench v2.1, SciCode,
  Humanity's Last Exam, GPQA Diamond, CritPt, AA-Omniscience, AA-LCR.
  `intelligenceIndexIsEstimated` = AA estimate (marked `*`), not yet measured.
- **Agentic Index (`agenticIndex`)** — subset weighting agentic evals.
- **Coding Index (`codingIndex`)** — subset weighting coding evals.
- **Omniscience (`omniscience`)** — factual recall minus hallucination across
  economically relevant domains; `omniscienceBreakdown` has accuracy and
  hallucinationRate separately.
- **Openness Index** (model page only, `openness.opennessIndex`) — composite
  industry-standard measure of model openness (availability, transparency,
  licensing).
- **AA-Briefcase Elo** (model page only) — private agentic knowledge-work
  benchmark: realistic long-horizon business workflows; reported as Elo with
  95% CI.

## Eval scores (fraction 0–1 in JSON; CLI prints %)

| field | eval | what it tests |
|---|---|---|
| gpqa | GPQA Diamond | Hardest 198 GPQA questions; PhD experts ~65%, non-experts ~34% |
| hle | Humanity's Last Exam | 2,500 expert-vetted frontier questions across math/science/humanities |
| scicode | SciCode | 288 scientist-curated coding subproblems from 80 lab problems, 16 disciplines |
| terminalbenchV21 | Terminal-Bench v2.1 | 89 curated agentic terminal tasks (SWE, sysadmin, data, training, security) |
| terminalbenchHard | Terminal-Bench Hard | Harder agentic terminal subset |
| tauBanking | τ³-Banking | Fintech customer support: navigate unstructured KB + multi-step tool calls |
| tau2 | τ²-Bench | Tool-use agent benchmark (telecom/retail domains) |
| gdpvalNormalized | GDPval-AA v2 | OpenAI GDPval run by AA: real-world tasks, 44 occupations, 9 industries, shell+web access. Raw `gdpval` (model page) is an Elo |
| critpt | CritPt | 71 composite research-level physics reasoning challenges |
| lcr | AA-LCR | Long-context reasoning: extract/synthesize over 10k–100k-token documents |
| ifbench | IFBench | Instruction-following on 58 verifiable out-of-domain constraints |
| mmmuPro | MMMU-Pro | Multimodal academic reasoning, 30 disciplines, shortcut-resistant |
| aime25 | AIME 2025 | 30 olympiad math problems, integer answers 000–999 |
| itbenchSre | ITBench-AA (SRE) | IBM ITBench: Kubernetes incident root-cause analysis |
| analystAgent | AA-AnalystAgent | Spreadsheet/document data-analysis tasks a business analyst faces |
| apexAgents | APEX-Agents-AA | Long-horizon cross-application professional-services agent tasks |
| livecodebench | LiveCodeBench | Contamination-free competitive programming (fresh LeetCode/AtCoder/CF) |
| mlcrOverall | MLCR-AA | Long fragmented medical-record multi-document reasoning (Wisedocs) |
| harveyLabCriteriaPass | Harvey LAB-AA | 120 real legal-work tasks, 24 practice areas |
| automationBenchPartialScore | AutomationBench-AA | Agentic SaaS workflow completion without guardrail violations |
| enterpriseOpsGym | EnterpriseOps-Gym-AA | ServiceNow enterprise multi-step stateful workflows |

## Pricing (USD per 1M tokens)

- `price1mInputTokens` / `price1mOutputTokens` — list API prices.
- `cacheHitPrice` — cached-input read price (`cacheHitDiscountPercent` = discount
  vs input). `cacheWritePrice` — cache storage write price (often null).
- `price1mBlended…` — blended in/out prices at fixed input:output ratios.
- **`costPerTask` — the metric to cite for "cost"**: AA's measured cost to run
  one average Intelligence Index task, including input, cache-hit, cache-write,
  reasoning, and answer tokens weighted by eval. Never recompute it from token
  prices. Model page adds `intelligenceIndexCostPerTask.cost` with a full
  breakdown (input/cacheRead/cacheWrite/reasoning/answer) and
  `intelligenceIndexOutputTokensPerTask` (verbosity: reasoning vs answer).

## Speed (median, measured by AA on the provider in `performanceDataSource`)

- `medianOutputTokensPerSecond` — output speed/throughput, tok/s (higher =
  better). This is what matters for bulk generation and coding.
- `medianTimeToFirstTokenSeconds` (TTFT) — latency to first chunk; this is
  what users feel as "snappiness" in chat/UI streaming. A model can have high
  tok/s AND high TTFT (long reasoning prep) — always check both.
- `medianTimeToFirstAnswerTokenSeconds` — TTFT + reasoning time.
- `medianEndToEndResponseTimeSeconds` — full response time.
- `medianReasoningTimeSeconds` — reasoning phase duration.
- `percentile05/95…`, `quartile25/75…` — variance bands. Model page adds
  `performanceByPromptType` (short/medium/long prompt splits).

## Identity / specs

`releaseDate`, `knowledgeCutoffDate` (model page), `isOpenWeights` +
`openSourceCategorization` + `licenseName`/`licenseUrl`, `totalParameters` /
`activeParameters` (billions), `contextWindowTokens`, `isReasoning` +
`effort.label` (low…max — same model appears once per effort with different
score/cost/speed), `deprecated` (+`deprecatedTo`), modalities
(`input/outputModality{Text,Image,Speech,Video}`), `huggingfaceUrl`,
`modelCreatorCountry`.

## Media leaderboards (Elo from human preference arenas)

`media` command tables: text-to-image, image-editing, text-to-video,
image-to-video ($/min pricing), text-to-speech ($/1M chars). Elo + 95% CI +
sample counts; higher Elo = better.

## Speech boards (from the homepage payload; no dedicated pages)

- **speech-to-text** / **speech-to-text-streaming** — `werIndex` = word error
  rate (lower = better; CLI prints %), plus `timeToFinalTranscriptSeconds`.
- **realtime-voice** (speech-to-speech) — `stsIndex` (0–100, higher = better);
  AA's realtime audio-to-audio quality index for models like GPT-Realtime and
  Qwen Audio Realtime.

## Provider endpoints (providers command / hostModels array)

Per model × provider endpoint:
- `pricing.price1mInputTokens` / `price1mOutputTokens` / `cacheHitPrice` —
  raw per-token rates; `cacheHitDiscountPercent` = cache-read discount vs
  input price; `cacheHitRate` = observed cache-hit fraction in AA's runs.
- `performance.outputSpeed.median` (tok/s), `timeToFirstToken.median` (TTFT),
  `timeToFirstAnswerToken`, `endToEndResponseTime`, `byPromptType` splits.
- `intelligenceIndexCostPerTask` — full cost breakdown for that endpoint.
- `functionCalling` / `jsonMode` — feature support flags.
- **Precision/quantization** (FP8, INT4, BF16, …) is encoded in the endpoint
  slug suffix (e.g. `siliconflow_deepseek-v4-pro-0813_fp8`); the CLI extracts
  it into the Precision column. Endpoints without a tag serve full precision
  or don't disclose it.
- Some endpoints carry per-endpoint eval spot-checks (`gpqa16x`, `aime25x32`,
  `ifbench8x`) — quality variance across providers/quantizations.

## Not tracked by Artificial Analysis

MathVista, DocVQA, and BFCL (Berkeley Function Calling Leaderboard) have **no
data on AA** — never quote numbers for them from this source. Closest AA
equivalents: vision → `mmmuPro` eval + modality flags; tool-calling →
`functionCalling`/`jsonMode` endpoint flags.