---
name: artificial-analysis
description: Live data from artificialanalysis.ai as the source of truth for AI model questions — Intelligence/Agentic/Coding Index rankings, per-benchmark scores (GPQA, HLE, Terminal-Bench, SciCode, AIME, MMMU-Pro, 20+ evals), API pricing incl. cache-aware cost per task, speed/latency, context windows, parameters, licenses, open-weights status, reasoning-effort variants, provider comparisons, and image/video/TTS arena leaderboards. Use for ANY question about how AI models benchmark, compare, or cost — rankings, "smartest/cheapest/fastest/best-value model", model spec lookups, model-vs-model comparisons, provider pricing/speed, or what a benchmark measures. Triggers on mentions of Artificial Analysis, Intelligence Index, model benchmarks, model pricing, or comparing models (GPT, Claude, Gemini, Kimi, DeepSeek, Qwen, Grok, GLM, Llama, etc.).
---

# Artificial Analysis

One CLI answers everything; no API key. Run from this skill's directory:

```bash
python3 scripts/aa.py &lt;command&gt; ...
```

First call downloads the leaderboard (~4.5 MB, embeds all ~600 model variants
× ~80 metrics) and caches it + every other page for 1 h in /tmp/aa_cache.
Later calls are instant. `--refresh` forces re-download (do this when the user
asks about a model released "today" or data looks stale).

## Route the question to a command

| User asks | Run |
|---|---|
| Top / smartest / best models now | `leaderboard --top 15` |
| Cheapest, best value, intelligence-per-$ | `leaderboard --value` (note absolute $ too) |
| Best under budget / above intel bar | `leaderboard --max-cost 0.10 --min-intel 45` |
| Fastest generation (bulk/coding) | `leaderboard --sort tps` |
| Snappiest response (UI streaming) | `leaderboard --sort ttft` |
| Pareto frontier, price-performance curve | `leaderboard --frontier` |
| Best open-weights / by creator / coding / agentic | `leaderboard --open-weights` / `--creator deepseek` / `--sort coding` / `--sort agentic` |
| "What models does X have?", unsure of a name | `search --creator anthropic` / `search "deepseek"` (never guess names) |
| Anything about ONE model (specs, price, scores, size, license, context, release date, cutoff) | `model "kimi k3 max"` |
| Model A vs B (vs C…) | `compare "kimi k3 max" "gpt-5.6 sol max"` |
| Raw input/output/cache prices | `model QUERY` (pricing section) or `providers QUERY` (per-endpoint) |
| Score on one benchmark, or best models at one benchmark | `evals "gpt-5.6 sol max"` / `evals --metric gpqa` |
| Which provider serves a model cheapest/fastest, at what quantization | `providers "deepseek v4 pro 0813"` (Precision col: FP8/INT4/…; In/Out/CacheRead $/1M; FnCall/JSON) |
| Provider landscape across models | `providers-board [--model X] [--provider azure]` |
| Image / video / TTS rankings | `media text-to-image|image-editing|text-to-video|image-to-video|text-to-speech` |
| Speech-to-text (transcription WER) | `media speech-to-text` / `media speech-to-text-streaming` |
| Realtime voice / speech-to-speech | `media realtime-voice` (STS Index, 0–100) |
| Question no table covers (weights URL, token counts, variance…) | `json "model"` or `json "model" --deep`, then read the field |
| What a metric/eval means | read `references/metrics.md` |

Names are fuzzy but include the effort when the user does ("claude opus 5
max"). When unsure of the exact name, run `search` first — it lists names and
slugs without burning a turn on an ambiguity error.

## Output size control

- `leaderboard --compact` → only Model, Intel, $/Task, tok/s, Ctx.
- `leaderboard --fields "intelligence,gpqa,cost_per_task,tps"` → exact columns.
- `compare --compact` → 5 core rows; `compare --fields "hle,tps,ttft"` → exact rows.
- Field names: run `fields`. Keep `--top` small (5–15) unless asked for more.

## Facts to trust, not re-derive

- **Cost per Task already includes cache-hit and cache-write pricing** (plus
  input/reasoning/answer tokens, weighted by eval). For "cost incl. caching"
  questions use it as-is; never recompute from $/1M token prices. When users
  ask for **raw rates**, quote the pricing section of `model` (In/Out/Cache
  Read/Cache Write $/1M) or the per-endpoint rates in `providers` — these are
  list prices, distinct from the blended task cost.
- **TTFT ≠ throughput.** A model can stream fast (high tok/s) yet feel slow
  (high TTFT from reasoning prep). For "snappy/responsive" use `--sort ttft`;
  for "generates fast / bulk output" use `--sort tps`. Report both when
  recommending.
- **Quantization matters for open-weights models**: the same model varies in
  speed and score by precision. The `providers` Precision column surfaces the
  tag (FP8, INT4, BF16…) when AA encodes it in the endpoint; mention it when
  comparing endpoints.
- **Not tracked by AA**: MathVista, DocVQA, BFCL (Berkeley function-calling).
  If asked, say AA has no such data — do not invent scores. For vision use
  the `mmmuPro` eval + modality flags; for tool-calling use the FnCall/JSON
  columns in `providers`.
- Each model appears **once per reasoning effort** (low…max) with different
  intel/cost/speed. Compare like-for-like and always name the effort.
- `*` after an Intelligence score = AA estimate, not yet measured. `—` = no data.
- Eval scores print as % (JSON stores 0–1 fractions). Indexes are 0–100.
- Answering pattern for "best X for Y": filter with flags → name the top rows
  → for value questions, point at the knee of the `--frontier` curve (last
  model before cost per intel point jumps ≥5×) → say where the user's named
  model sits vs. the frontier.
- Cite as "live data scraped from artificialanalysis.ai on &lt;today's date&gt;".

## Token discipline

- Outputs are pre-rounded; don't re-print raw JSON when a table command exists.
- Reach for `--compact` / `--fields` before pasting wide tables into context.
- `json` dumps full records — grep/extract the needed field, never paste it all.

## Failure handling

- **Cloudflare / bot mitigation**: AA sometimes answers curl with a managed
  challenge (HTTP 403/503, empty or tiny body). The fix is a browser engine:
  use the `playwright-scraper-skill` or `fast-browser-use` skill to render the
  failing URL, save the HTML over the exact cache path printed in the error
  (e.g. /tmp/aa_cache/leaderboard.html), then re-run — the CLI picks it up.
- **Next.js build-ID churn**: AA redeploys often, and every deploy changes
  the `/_next/static/...` chunk paths and can shift the RSC payload layout.
  Never hardcode chunk URLs or `/_next/data/&lt;buildId&gt;/...` endpoints — the CLI
  always scrapes the payload from freshly fetched HTML. If you ever call RSC
  JSON endpoints directly, scrape the current `buildId` from the root HTML
  first; it is invalid after the next deploy.
- **Structure changes**: if parsing fails, render the page via browser as
  above; if the RSC layout moved, patch `find_array` /
  `extract_keyed_object` in scripts/aa.py. The HTML-table fallback
  (`pandas.read_html` on /leaderboards/models) still yields
  Model/Context/Creator/Intelligence/Cost/Speed/Latency, and `providers`
  falls back to its rendered table automatically.