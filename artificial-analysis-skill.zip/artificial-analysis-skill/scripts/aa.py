#!/usr/bin/env python3
"""CLI for artificialanalysis.ai (AA) — no API key needed.

Data source: AA pages are server-rendered Next.js. The leaderboard HTML embeds
an RSC (react-server-component) payload with a JSON array of ALL ~600 model
variants x ~80 metrics (evals, pricing, speed). One curl gets everything.
Per-model pages embed an even richer `currentModel` object (cost breakdown,
token counts, openness, briefcase Elo). Provider and media leaderboards are
plain HTML tables. The public JSON API requires a key — never use it.

Commands:
  leaderboard   Rank/filter all models. --value --frontier --sort F --model X
                --creator X --min-intel N --max-cost N --min-speed N
                --open-weights --reasoning --all --compact --fields F,F
                --top N --csv PATH
                Sorts: tps (throughput) vs ttft (snappiness) are distinct;
                speed/latency are aliases of tps/ttft.
  search [Q]    List models + slugs (--creator --open-weights); alias: list.
                Use this instead of guessing names — no ambiguity errors.
  model QUERY   Full digest for one model: identity, indexes, eval scores,
                raw + cache pricing, speed, cost breakdown, openness.
  compare Q...  Side-by-side metric table for 2+ models. --compact --fields.
  evals QUERY   Per-benchmark scores for one model.
  evals --metric gpqa [--top N]   Cross-model ranking on one benchmark.
  providers QUERY   API endpoints for one model: precision/quantization tag,
                raw In/Out/CacheRead $/1M, $/task, tps, TTFT, FnCall, JSON.
  providers-board [--model X] [--provider X]  Global provider x model table.
  media KIND    text-to-image | image-editing | text-to-video |
                image-to-video | text-to-speech | speech-to-text |
                speech-to-text-streaming | realtime-voice
  json QUERY    Raw JSON record(s) — use for questions nothing else covers.
  fields        List --fields names and every raw metric field.

All: --refresh ignores the 1h cache. Numbers are rounded for token efficiency;
use `json` for full precision. '*' after a score = AA estimate. '—' = no data.
"""

import argparse
import json
import os
import re
import subprocess
import sys
import time

BASE = "https://artificialanalysis.ai"
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
CACHE = "/tmp/aa_cache"
LB_HTML = f"{CACHE}/leaderboard.html"
LB_JSON = f"{CACHE}/models.json"
MODEL_HTML = f"{CACHE}/model_{{slug}}.html"
TTL = 3600  # seconds

# ---------------------------------------------------------------- data layer


def fetch(url: str, path: str, min_bytes: int = 500_000) -> None:
    """curl download (plain requests sometimes gets 403); fail loudly."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    r = subprocess.run(["curl", "-sfL", url, "-H", f"User-Agent: {UA}", "-o", path],
                       capture_output=True, text=True, timeout=300)
    ok = r.returncode == 0 and os.path.exists(path) and os.path.getsize(path) >= min_bytes
    if not ok:
        sys.exit(f"Fetch of {url} failed (stderr: {r.stderr.strip()!r}). Site may have "
                 f"changed — render it with a browser skill and save the HTML to {path}")


def fresh(path: str) -> bool:
    return os.path.exists(path) and time.time() - os.path.getmtime(path) <= TTL


def cached(url: str, path: str, refresh: bool, min_bytes: int = 500_000) -> str:
    if refresh or not fresh(path):
        fetch(url, path, min_bytes)
    return path


def rsc_payload(html: str) -> str:
    """Concatenate the self.__next_f.push RSC string chunks into one payload."""
    chunks = re.findall(r'self\.__next_f\.push\(\[1,("(?:[^"\\]|\\.)*")\]\)', html)
    if not chunks:
        sys.exit("No RSC payload found — site structure changed. See SKILL.md fallback.")
    return "".join(json.loads(c) for c in chunks)


def find_array(payload: str, required_key: str):
    """Find the first JSON array of dicts containing required_key."""
    for m in re.finditer(r'"(?:models|data|rows|items)":\s*\[\{', payload):
        i = payload.find("[", m.start())
        try:
            arr, _ = json.JSONDecoder().raw_decode(payload[i:])
        except json.JSONDecodeError:
            continue
        dicts = [x for x in arr if isinstance(x, dict)]
        if dicts and required_key in dicts[0]:
            return dicts
    return None


def extract_keyed_object(payload: str, key: str):
    """Extract the JSON object assigned to `"key":` in the payload."""
    i = payload.find(f'"{key}":')
    if i < 0:
        return None
    j = payload.find("{", i)
    try:
        obj, _ = json.JSONDecoder().raw_decode(payload[j:])
        return obj
    except json.JSONDecodeError:
        return None


def load_models(refresh: bool = False) -> list:
    """All model variants (~600) with ~80 metrics + CostPerTask merged in."""
    if not refresh and fresh(LB_JSON):
        return json.load(open(LB_JSON, encoding="utf-8"))
    path = cached(f"{BASE}/leaderboards/models", LB_HTML, refresh)
    html = open(path, encoding="utf-8").read()
    arr = find_array(rsc_payload(html), "intelligenceIndex")
    if not arr:
        sys.exit("Model array not found in leaderboard payload — site changed.")
    # Cost per Task lives only in the rendered table; merge via shortName.
    import pandas as pd
    t = pd.read_html(path)[0]
    t.columns = ["Model", "Context", "Creator", "Intelligence", "CostPerTask",
                 "Speed", "Latency", "E2E", "x"][: len(t.columns)]
    cost = {}
    for _, r in t.iterrows():
        v = pd.to_numeric(str(r["CostPerTask"]).replace("$", "").replace(",", ""),
                          errors="coerce")
        cost[str(r["Model"])] = None if pd.isna(v) else float(v)
    for m in arr:
        m["costPerTask"] = cost.get(m.get("shortName") or m.get("name"))
    os.makedirs(CACHE, exist_ok=True)
    json.dump(arr, open(LB_JSON, "w"))
    return arr


def load_model_page(slug: str, refresh: bool = False) -> dict:
    """Rich `currentModel` object from /models/<slug>."""
    path = cached(f"{BASE}/models/{slug}", MODEL_HTML.format(slug=slug), refresh)
    obj = extract_keyed_object(rsc_payload(open(path, encoding="utf-8").read()),
                               "currentModel")
    return obj or {}


def norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", (s or "").lower())


def find_models(models: list, query: str) -> list:
    """Fuzzy match on shortName/name/slug; best (highest-intel) first."""
    nq = norm(query)
    exact = [m for m in models if nq in (norm(m.get("shortName")), norm(m.get("name")),
                                         norm((m.get("slug") or "").replace("-", "")))]
    hits = exact or [m for m in models
                     if nq in norm(m.get("shortName")) or nq in norm(m.get("name"))
                     or nq in norm((m.get("slug") or "").replace("-", ""))]
    return sorted(hits, key=lambda m: (m.get("intelligenceIndex") is None,
                                       -(m.get("intelligenceIndex") or 0)))


def resolve(models: list, query: str) -> dict:
    """Resolve to a single model; print candidates and exit if ambiguous."""
    hits = find_models(models, query)
    if not hits:
        sys.exit(f"No model matching {query!r}. Try `leaderboard --model {query}` "
                 "to browse names.")
    if len(hits) > 1:
        print(f"# {len(hits)} matches for {query!r} — re-run with a fuller name:\n")
        rows = [[m.get("shortName") or m["name"], m.get("modelCreatorName") or "—",
                 f1(m.get("intelligenceIndex")), money(m.get("costPerTask")),
                 m.get("slug")] for m in hits[:20]]
        print(md_table(["Name", "Creator", "Intel", "$/Task", "slug"], rows))
        sys.exit(1)
    return hits[0]

# ---------------------------------------------------------------- formatting


def f1(v, est: bool = False) -> str:
    if v is None:
        return "—"
    return f"{v:.1f}" + ("*" if est else "")


def f0(v) -> str:
    return "—" if v is None else f"{v:.0f}"


def pct(v) -> str:
    return "—" if v is None else f"{v * 100:.1f}"


def money(v, digits: int = 2) -> str:
    if v is None:
        return "—"
    return f"${v:,.{digits}f}"


def num(v) -> str:
    return "—" if v is None else f"{v:,.0f}"


def yn(v) -> str:
    return "yes" if v else "no"


def md_table(headers: list, rows: list) -> str:
    lines = ["| " + " | ".join(headers) + " |",
             "|" + "---|" * len(headers)]
    lines += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(lines)


# Metric catalog: (json_field, label, formatter_key)
EVALS = [("gpqa", "GPQA Diamond", "pct"), ("hle", "Humanity's Last Exam", "pct"),
         ("scicode", "SciCode", "pct"), ("terminalbenchV21", "Terminal-Bench v2.1", "pct"),
         ("terminalbenchHard", "Terminal-Bench Hard", "pct"),
         ("tauBanking", "tau3-Banking", "pct"), ("tau2", "tau2-Bench", "pct"),
         ("gdpvalNormalized", "GDPval-AA", "pct"), ("critpt", "CritPt (physics)", "pct"),
         ("lcr", "AA-LCR (long-context)", "pct"), ("ifbench", "IFBench", "pct"),
         ("mmmuPro", "MMMU-Pro", "pct"), ("aime25", "AIME 2025", "pct"),
         ("itbenchSre", "ITBench-SRE", "pct"), ("analystAgent", "AA-Analyst Agent", "pct"),
         ("apexAgents", "APEX-Agents", "pct")]
# Extra evals only present on per-model pages:
EVALS_DEEP = [("livecodebench", "LiveCodeBench", "pct"),
              ("mlcrOverall", "AA-MLCR", "pct"),
              ("harveyLabCriteriaPass", "Harvey-Lab pass", "pct"),
              ("automationBenchPartialScore", "AutomationBench-AA", "pct"),
              ("enterpriseOpsGym", "Enterprise Ops Gym", "pct"),
              ("gdpval", "GDPval-AA Elo", "f0")]
INDEXES = [("intelligenceIndex", "Intelligence Index"), ("agenticIndex", "Agentic Index"),
           ("codingIndex", "Coding Index"), ("omniscience", "Omniscience (knowledge)")]

# ---------------------------------------------------------------- commands

SORTS = {"intel": lambda m: m.get("intelligenceIndex"),
         "cost": lambda m: m.get("costPerTask"),
         "tps": lambda m: m.get("medianOutputTokensPerSecond"),
         "speed": lambda m: m.get("medianOutputTokensPerSecond"),  # alias of tps
         "ttft": lambda m: m.get("medianTimeToFirstTokenSeconds"),
         "latency": lambda m: m.get("medianTimeToFirstTokenSeconds"),  # alias of ttft
         "e2e": lambda m: m.get("medianEndToEndResponseTimeSeconds"),
         "context": lambda m: m.get("contextWindowTokens"),
         "price-in": lambda m: m.get("price1mInputTokens"),
         "price-out": lambda m: m.get("price1mOutputTokens"),
         "released": lambda m: m.get("releaseDate"),
         "agentic": lambda m: m.get("agenticIndex"),
         "coding": lambda m: m.get("codingIndex"),
         "omniscience": lambda m: m.get("omniscience")}
ASCENDING = {"cost", "ttft", "latency", "e2e", "price-in", "price-out"}

# Friendly field names for --fields (leaderboard columns / compare rows).
FIELDS = {"intelligence": ("Intel", lambda m: f1(m.get("intelligenceIndex"), m.get("intelligenceIndexIsEstimated"))),
          "agentic": ("Agentic", lambda m: f1(m.get("agenticIndex"))),
          "coding": ("Coding", lambda m: f1(m.get("codingIndex"))),
          "omniscience": ("Omnisc", lambda m: f1(m.get("omniscience"))),
          "cost": ("$/Task", lambda m: money(m.get("costPerTask"))),
          "cost_per_task": ("$/Task", lambda m: money(m.get("costPerTask"))),
          "input_price": ("In$/1M", lambda m: money(m.get("price1mInputTokens"))),
          "output_price": ("Out$/1M", lambda m: money(m.get("price1mOutputTokens"))),
          "cache_read": ("CacheR$/1M", lambda m: money(m.get("cacheHitPrice"))),
          "cache_write": ("CacheW$/1M", lambda m: money(m.get("cacheWritePrice"))),
          "tps": ("tok/s", lambda m: f1(m.get("medianOutputTokensPerSecond"))),
          "ttft": ("TTFTs", lambda m: f1(m.get("medianTimeToFirstTokenSeconds"))),
          "e2e": ("E2Es", lambda m: f1(m.get("medianEndToEndResponseTimeSeconds"))),
          "context": ("Ctx", lambda m: short_ctx(m.get("contextWindowTokens"))),
          "params": ("ParamsB", lambda m: f0(m.get("totalParameters"))),
          "active_params": ("ActiveB", lambda m: f0(m.get("activeParameters"))),
          "released": ("Released", lambda m: m.get("releaseDate") or "—"),
          "open_weights": ("OpenW", lambda m: yn(m.get("isOpenWeights"))),
          "reasoning": ("Reason", lambda m: yn(m.get("isReasoning"))),
          "creator": ("Creator", lambda m: m.get("modelCreatorName") or "—")}
FIELDS.update({k: (lbl, lambda m, k=k: pct(m.get(k))) for k, lbl, _ in EVALS})


def parse_fields(spec: str) -> list:
    """Resolve a comma list of friendly field names to (label, fn) pairs."""
    out, bad = [], []
    for name in spec.split(","):
        key = name.strip().lower().replace("-", "_").replace(" ", "_")
        hit = FIELDS.get(key) or next((v for k, v in FIELDS.items()
                                       if key in k or key in norm(v[0])), None)
        (out.append(hit) if hit else bad.append(name))
    if bad:
        print(f"# warning: unknown fields {bad} — run `fields` for options",
              file=sys.stderr)
    return out


def cmd_leaderboard(a) -> None:
    d = load_models(a.refresh)
    if not a.all:
        d = [m for m in d if not m.get("deprecated")
             and m.get("intelligenceIndex") is not None]
    if a.model:
        d = [m for m in d if a.model.lower() in (m.get("shortName") or m["name"]).lower()]
    if a.creator:
        q = a.creator.lower()
        d = [m for m in d if q in (m.get("modelCreatorName") or "").lower()
             or q in (m.get("shortName") or m["name"]).lower()]
    if a.open_weights:
        d = [m for m in d if m.get("isOpenWeights")]
    if a.reasoning is not None:
        d = [m for m in d if bool(m.get("isReasoning")) == a.reasoning]
    if a.min_intel is not None:
        d = [m for m in d if (m.get("intelligenceIndex") or 0) >= a.min_intel]
    if a.max_cost is not None:
        d = [m for m in d if m.get("costPerTask") is not None
             and m["costPerTask"] <= a.max_cost]
    if a.min_speed is not None:
        d = [m for m in d if (m.get("medianOutputTokensPerSecond") or 0) >= a.min_speed]
    if a.frontier:
        d = pareto(d)
        key, rev = SORTS["cost"], False
    elif a.value:
        d = [m for m in d if (m.get("costPerTask") or 0) > 0
             and m.get("intelligenceIndex") is not None]
        for m in d:
            m["_value"] = m["intelligenceIndex"] / m["costPerTask"]
        key, rev = lambda m: m["_value"], True
    else:
        key = SORTS[a.sort]
        rev = a.sort not in ASCENDING
    d = sorted(d, key=lambda m: (key(m) is None, key(m) or 0), reverse=rev)
    if a.fields:
        sel = parse_fields(a.fields)
        cols = ["Model"] + [lbl for lbl, _ in sel]
        rows = [[m.get("shortName") or m["name"]] + [fn(m) for _, fn in sel]
                for m in d[: a.top]]
    else:
        if a.compact:
            cols = ["Model", "Intel", "$/Task", "tok/s", "Ctx"]
        else:
            cols = ["Model", "Creator", "Intel", "$/Task", "tok/s", "TTFTs", "Ctx"]
        if a.value:
            cols.append("Intel/$")
        rows = []
        for m in d[: a.top]:
            r = [m.get("shortName") or m["name"],
                 f1(m.get("intelligenceIndex"), m.get("intelligenceIndexIsEstimated")),
                 money(m.get("costPerTask")), f0(m.get("medianOutputTokensPerSecond"))]
            if not a.compact:
                r.insert(1, m.get("modelCreatorName") or "—")
                r.append(f1(m.get("medianTimeToFirstTokenSeconds")))
            r.append(short_ctx(m.get("contextWindowTokens")))
            if a.value:
                r.append(f0(m["_value"]))
            rows.append(r)
    print(f"# {len(d)} models (of {len(load_models())} tracked) — sorted by "
          + ("value intel-per-$" if a.value else "Pareto frontier" if a.frontier else a.sort)
          + f", top {min(a.top, len(rows))}\n")
    print(md_table(cols, rows))
    if a.csv:
        import csv
        with open(a.csv, "w", newline="") as fh:
            csv.writer(fh).writerows([cols] + rows)
        print(f"\nWrote {a.csv}")


def pareto(d: list) -> list:
    """Keep models whose Intelligence exceeds every cheaper model's."""
    s = sorted([m for m in d if m.get("costPerTask") and m.get("intelligenceIndex")],
               key=lambda m: (m["costPerTask"], -m["intelligenceIndex"]))
    out, best = [], -1.0
    for m in s:
        if m["intelligenceIndex"] > best:
            out.append(m)
            best = m["intelligenceIndex"]
    return out


def short_ctx(v) -> str:
    if v is None:
        return "—"
    return f"{v / 1_000_000:.1f}M" if v >= 1_000_000 else f"{v // 1000}k"


def digest(m: dict, deep: dict) -> None:
    """Full one-model digest. m = leaderboard record, deep = currentModel."""
    name = m.get("shortName") or m["name"]
    url = f"{BASE}/models/{m['slug']}"
    print(f"# {name} — {m.get('modelCreatorName') or '?'} — {url}\n")
    modalities_in = [k for k in ("text", "image", "speech", "video")
                     if m.get(f"inputModality{k.capitalize()}")]
    modalities_out = [k for k in ("text", "image", "speech", "video")
                      if m.get(f"outputModality{k.capitalize()}")]
    params = ""
    if m.get("totalParameters"):
        params = f"{f0(m['totalParameters'])}B params"
        if m.get("activeParameters"):
            params += f" ({f0(m['activeParameters'])}B active)"
    openw = ("open weights" + (f" ({m['licenseName']})" if m.get("licenseName") else "")) \
        if m.get("isOpenWeights") else "proprietary"
    facts = [f"Released {m.get('releaseDate') or '?'}", openw, params,
             f"Context {num(m.get('contextWindowTokens'))} tok",
             f"In: {'+'.join(modalities_in) or '?'} / Out: {'+'.join(modalities_out) or '?'}",
             f"Reasoning: {yn(m.get('isReasoning'))}" + effort_str(deep),
             "DEPRECATED" if m.get("deprecated") else ""]
    print(" · ".join(x for x in facts if x))
    print("\n## Intelligence (0–100, higher=better)")
    idx = " · ".join(f"{lbl} {f1(m.get(k), k == 'intelligenceIndex' and m.get('intelligenceIndexIsEstimated'))}"
                     for k, lbl in INDEXES if m.get(k) is not None)
    print(idx or "—")
    rows = [[lbl, pct(m.get(k))] for k, lbl, _ in EVALS if m.get(k) is not None]
    rows += [[lbl, pct(deep.get(k)) if f == "pct" else f0(deep.get(k))]
             for k, lbl, f in EVALS_DEEP if deep.get(k) is not None]
    if rows:
        print("\n## Eval scores (% correct unless noted)")
        print(md_table(["Eval", "Score"], rows))
    print("\n## Pricing (USD per 1M tokens)")
    pr = [f"Input {money(m.get('price1mInputTokens'))}",
          f"Output {money(m.get('price1mOutputTokens'))}"]
    if m.get("cacheHitPrice") is not None:
        pr.append(f"Cache hit {money(m['cacheHitPrice'])}")
    if m.get("cacheWritePrice") is not None:
        pr.append(f"Cache write {money(m['cacheWritePrice'])}")
    pr.append(f"Cost per AA task {money(m.get('costPerTask'))}")
    print(" · ".join(pr))
    print("\n## Speed (median, first-party measurement)")
    sp = [f"Output {f1(m.get('medianOutputTokensPerSecond'))} tok/s",
          f"TTFT {f1(m.get('medianTimeToFirstTokenSeconds'))}s",
          f"E2E {f1(m.get('medianEndToEndResponseTimeSeconds'))}s"]
    print(" · ".join(sp))
    if deep:
        print_deep_extras(deep)


def effort_str(deep: dict) -> str:
    e = (deep or {}).get("effort") or {}
    return f" (effort: {e['label']})" if e.get("label") else ""


def print_deep_extras(d: dict) -> None:
    cpt = ((d.get("intelligenceIndexCostPerTask") or {}).get("cost") or {})
    if cpt.get("total") is not None:
        print("\n## Cost per task breakdown (USD; cache-aware)")
        print(f"Total {money(cpt.get('total'), 3)} · input {money(cpt.get('input'), 3)} "
              f"(cache read {money(cpt.get('cacheRead'), 3)}, write {money(cpt.get('cacheWrite'), 3)}) "
              f"· reasoning {money(cpt.get('reasoning'), 3)} · answer {money(cpt.get('answer'), 3)}")
    tok = d.get("intelligenceIndexOutputTokensPerTask") or {}
    if tok.get("output"):
        print(f"Output tokens/task: {num(tok.get('output'))} "
              f"(reasoning {num(tok.get('reasoning'))}, answer {num(tok.get('answer'))})")
    op = d.get("openness") or {}
    if op.get("opennessIndex") is not None:
        print(f"\nOpenness Index {f1(op['opennessIndex'])}/100")
    br = (d.get("briefcaseBreakdown") or {}).get("overall") or {}
    if br.get("elo"):
        print(f"AA-Briefcase Elo {f0(br['elo'])} "
              f"(95% CI {f0(br.get('lower95ci'))}–{f0(br.get('upper95ci'))})")
    src = d.get("performanceDataSource") or {}
    if src.get("providerName"):
        print(f"Speed measured on: {src['providerName']}")
    if d.get("knowledgeCutoffDate"):
        print(f"Knowledge cutoff: {d['knowledgeCutoffDate']}")


def cmd_search(a) -> None:
    """List matching models + slugs without triggering ambiguity errors."""
    d = load_models(a.refresh)
    if not a.all:
        d = [m for m in d if not m.get("deprecated")]
    if a.query:
        d = find_models(d, a.query) or [
            m for m in d if a.query.lower()
            in ((m.get("shortName") or "") + (m.get("modelCreatorName") or "")).lower()]
    if a.creator:
        q = a.creator.lower()
        d = [m for m in d if q in (m.get("modelCreatorName") or "").lower()
             or q in (m.get("shortName") or m["name"]).lower()]
    if a.open_weights:
        d = [m for m in d if m.get("isOpenWeights")]
    d = sorted(d, key=lambda m: (m.get("intelligenceIndex") is None,
                                 -(m.get("intelligenceIndex") or 0)))
    rows = [[m.get("shortName") or m["name"], m.get("modelCreatorName") or "—",
             f1(m.get("intelligenceIndex")), money(m.get("costPerTask")),
             m.get("slug")] for m in d[: a.top]]
    print(f"# {len(d)} models match (top {min(a.top, len(rows))})\n")
    print(md_table(["Name", "Creator", "Intel", "$/Task", "slug"], rows))


def cmd_model(a) -> None:
    models = load_models(a.refresh)
    m = resolve(models, a.query)
    deep = load_model_page(m["slug"], a.refresh)
    digest(m, deep)


COMPARE_ROWS = [("Intelligence Index", lambda m, d: f1(m.get("intelligenceIndex"), m.get("intelligenceIndexIsEstimated"))),
                ("Agentic Index", lambda m, d: f1(m.get("agenticIndex"))),
                ("Coding Index", lambda m, d: f1(m.get("codingIndex"))),
                ("Omniscience", lambda m, d: f1(m.get("omniscience"))),
                ("Cost per task", lambda m, d: money(m.get("costPerTask"))),
                ("Input $/1M", lambda m, d: money(m.get("price1mInputTokens"))),
                ("Output $/1M", lambda m, d: money(m.get("price1mOutputTokens"))),
                ("Speed tok/s", lambda m, d: f1(m.get("medianOutputTokensPerSecond"))),
                ("TTFT s", lambda m, d: f1(m.get("medianTimeToFirstTokenSeconds"))),
                ("Context", lambda m, d: short_ctx(m.get("contextWindowTokens"))),
                ("Params B", lambda m, d: f0(m.get("totalParameters"))),
                ("Open weights", lambda m, d: yn(m.get("isOpenWeights"))),
                ("Reasoning", lambda m, d: yn(m.get("isReasoning")) + effort_str(d)),
                ("Released", lambda m, d: m.get("releaseDate") or "—")]
COMPARE_ROWS += [(lbl, lambda m, d, k=k: pct(m.get(k))) for k, lbl, _ in EVALS[:10]]


COMPACT_ROWS = {"Intelligence Index", "Cost per task", "Speed tok/s", "TTFT s",
                "Context"}


def cmd_compare(a) -> None:
    models = load_models(a.refresh)
    picked = [resolve(models, q) for q in a.queries]
    headers = ["Metric"] + [m.get("shortName") or m["name"] for m in picked]
    if a.fields:
        sel = parse_fields(a.fields)
        rows = [[lbl] + [fn(m) for m in picked] for lbl, fn in sel]
    else:
        deeps = [load_model_page(m["slug"], a.refresh) for m in picked]
        spec = COMPARE_ROWS if not a.compact else [r for r in COMPARE_ROWS
                                                   if r[0] in COMPACT_ROWS]
        rows = [[lbl] + [fn(m, d) for m, d in zip(picked, deeps)]
                for lbl, fn in spec]
    print(md_table(headers, rows))


def cmd_evals(a) -> None:
    models = load_models(a.refresh)
    if a.metric:
        field = a.metric.lower()
        match = [k for k, lbl, _ in EVALS + EVALS_DEEP
                 if field in k.lower() or field in norm(lbl)]
        if not match:
            sys.exit(f"Unknown metric {a.metric!r}. Options: "
                     + ", ".join(k for k, _, _ in EVALS + EVALS_DEEP))
        k = match[0]
        lbl = dict((kk, ll) for kk, ll, _ in EVALS + EVALS_DEEP)[k]
        d = [m for m in models if m.get(k) is not None and not m.get("deprecated")]
        d.sort(key=lambda m: m[k], reverse=True)
        rows = [[m.get("shortName") or m["name"], m.get("modelCreatorName") or "—",
                 pct(m[k]), f1(m.get("intelligenceIndex"))] for m in d[: a.top]]
        print(f"# {lbl} — top {min(a.top, len(rows))} of {len(d)} scored models\n")
        print(md_table(["Model", "Creator", lbl + " %", "Intel"], rows))
        return
    m = resolve(models, a.query)
    deep = load_model_page(m["slug"], a.refresh)
    rows = [[lbl, pct(m.get(k))] for k, lbl, _ in EVALS if m.get(k) is not None]
    rows += [[lbl, pct(deep.get(k)) if f == "pct" else f0(deep.get(k))]
             for k, lbl, f in EVALS_DEEP if deep.get(k) is not None]
    print(f"# {m.get('shortName') or m['name']} — eval scores (% unless noted)\n")
    print(md_table(["Eval", "Score"], rows) if rows else "No eval data.")


def clean_provider_table(path: str):
    """Flatten AA's two-row provider tables; keep the informative columns."""
    import pandas as pd
    t = pd.read_html(path)[0]
    rename = {"API Provider": "Provider", "Model": "Model",
              "Context Window": "Context", "License": "License",
              "Artificial Analysis Intelligence Index": "Intel",
              "Cost per TaskUSD": "$/Task", "MedianTokens/s": "tok/s",
              "MedianFirst Chunk (s)": "TTFTs", "TotalResponse (s)": "E2Es",
              "ReasoningTime (s)": "ReasoningS"}
    t.columns = [rename.get(str(c[-1])) for c in t.columns]
    t = t.loc[:, [c for c in t.columns if c]]  # drop unmapped (FnCall, JSON, ...)
    return t.dropna(how="all")


PRECISION_TAGS = ("fp4", "fp8", "fp16", "bf16", "int4", "int8", "awq", "gptq")


def load_provider_endpoints(slug: str, refresh: bool) -> list:
    """hostModels array from /models/<slug>/providers RSC payload."""
    path = cached(f"{BASE}/models/{slug}/providers",
                  f"{CACHE}/providers_{slug}.html", refresh)
    payload = rsc_payload(open(path, encoding="utf-8").read())
    i = payload.find('"hostModels":[{')
    if i < 0:
        return []
    arr, _ = json.JSONDecoder().raw_decode(payload[payload.find("[", i):])
    return [x for x in arr if isinstance(x, dict)]


def precision_of(ep: dict) -> str:
    """Quantization/precision tag from the endpoint slug, e.g. '..._fp8'."""
    tail = (ep.get("slug") or "").split("_")[-1].lower()
    return tail.upper() if tail in PRECISION_TAGS else "—"


def cmd_providers(a) -> None:
    models = load_models(a.refresh)
    m = resolve(models, a.query)
    eps = load_provider_endpoints(m["slug"], a.refresh)
    name = m.get("shortName") or m["name"]
    url = f"{BASE}/models/{m['slug']}/providers"
    if not eps:  # fallback: rendered HTML table (no token prices/precision)
        t = clean_provider_table(cached(url, f"{CACHE}/providers_{m['slug']}.html",
                                        a.refresh))
        print(f"# {name} — {len(t)} API providers ({url})\n")
        print(t.to_markdown(index=False))
        return
    rows = []
    for ep in sorted(eps, key=lambda e: (((e.get("performance") or {})
                                           .get("intelligenceIndexCostPerTask") or {})
                                         .get("total") or 9e9)):
        pr, perf = ep.get("pricing") or {}, ep.get("performance") or {}
        cpt = perf.get("intelligenceIndexCostPerTask") or {}
        disc = pr.get("cacheHitDiscountPercent")
        rows.append([(ep.get("host") or {}).get("label") or "—",
                     precision_of(ep),
                     money(pr.get("price1mInputTokens")),
                     money(pr.get("price1mOutputTokens")),
                     money(pr.get("cacheHitPrice"))
                     + (f" (-{disc * 100:.0f}%)" if disc else ""),
                     money(cpt.get("total")),
                     f0((perf.get("outputSpeed") or {}).get("median")),
                     f1((perf.get("timeToFirstToken") or {}).get("median")),
                     f1((perf.get("endToEndResponseTime") or {}).get("totalTime")),
                     yn(ep.get("functionCalling")), yn(ep.get("jsonMode"))])
    print(f"# {name} — {len(rows)} API endpoints, cheapest first ({url})\n")
    print(md_table(["Provider", "Precision", "In$/1M", "Out$/1M", "CacheR$/1M",
                    "$/Task", "tok/s", "TTFTs", "E2Es", "FnCall", "JSON"], rows))


def cmd_providers_board(a) -> None:
    path = cached(f"{BASE}/leaderboards/providers", f"{CACHE}/providers_board.html",
                  a.refresh)
    t = clean_provider_table(path)
    if a.model:
        t = t[t["Model"].astype(str).str.contains(a.model, case=False, na=False)]
    if a.provider:
        t = t[t["Provider"].astype(str).str.contains(a.provider, case=False, na=False)]
    print(f"# {len(t)} provider x model endpoints\n")
    print(t.head(a.top).to_markdown(index=False))


MEDIA = {"text-to-image": "/image/leaderboard/text-to-image",
         "image-editing": "/image/leaderboard/editing",
         "text-to-video": "/video/leaderboard/text-to-video",
         "image-to-video": "/video/leaderboard/image-to-video",
         "text-to-speech": "/text-to-speech/leaderboard/provider-voice"}
# Speech boards embedded in the homepage RSC payload (no dedicated page):
#   key -> (payload key, metric field, higher_is_better, metric label)
SPEECH = {"speech-to-text": ("sttNonStreaming", "werIndex", False, "WER"),
          "speech-to-text-streaming": ("sttStreaming", "werIndex", False, "WER"),
          "realtime-voice": ("sts", "stsIndex", True, "STS Index")}


def load_home_board(key: str, refresh: bool) -> dict:
    path = cached(BASE + "/", f"{CACHE}/home.html", refresh)
    payload = rsc_payload(open(path, encoding="utf-8").read())
    i = payload.find(f'"{key}":{{"models":[')
    if i < 0:
        sys.exit(f"Homepage board {key!r} not found — site changed.")
    obj, _ = json.JSONDecoder().raw_decode(payload[payload.find("{", i + len(key) + 2):])
    return obj


def cmd_media(a) -> None:
    if a.kind in SPEECH:
        key, metric, higher, lbl = SPEECH[a.kind]
        board = load_home_board(key, a.refresh)
        ms = sorted(board.get("models", []),
                    key=lambda x: (x.get(metric) is None,
                                   -(x.get(metric) or 0) if higher
                                   else (x.get(metric) or 9e9)))
        rows = []
        for x in ms[: a.top]:
            v = x.get(metric)
            score = f1(v) if higher else (f"{v * 100:.2f}%" if v is not None else "—")
            lat = x.get("timeToFinalTranscriptSeconds")
            rows.append([x.get("name") or "—",
                         x.get("creatorName") or x.get("hostName") or "—", score,
                         f1(lat) if lat is not None else "—"])
        print(f"# {a.kind} leaderboard — top {len(rows)} of "
              f"{board.get('totalCount', len(ms))} ({lbl} "
              f"{'higher=better' if higher else 'lower=better'})\n")
        print(md_table(["Model", "Creator", lbl, "FinalTranscriptS"], rows))
        return
    slug = MEDIA[a.kind]
    path = cached(BASE + slug, f"{CACHE}/media_{a.kind}.html", a.refresh)
    import pandas as pd
    t = pd.read_html(path)[0]
    t = t.loc[:, [c for c in t.columns
                  if not str(c).startswith("Unnamed") and "CI" not in str(c)]]
    t.columns = [re.sub(r"\s*\d+$", "", str(c)) for c in t.columns]
    print(f"# {a.kind} leaderboard ({BASE}{slug}) — top {min(a.top, len(t))} of {len(t)}\n")
    print(t.head(a.top).to_markdown(index=False))


def cmd_json(a) -> None:
    models = load_models(a.refresh)
    hits = find_models(models, a.query)[: a.top]
    out = []
    for m in hits:
        rec = dict(m)
        if a.deep:
            rec["_deep"] = load_model_page(m["slug"], a.refresh)
        out.append(rec)
    print(json.dumps(out if len(out) != 1 else out[0], indent=1, default=str))


def cmd_fields(a) -> None:
    print("""# --fields names (for leaderboard/compare): """
          + ", ".join(sorted(FIELDS)) + """

# Raw JSON fields (see references/metrics.md for definitions)
Indexes (0-100): intelligenceIndex, agenticIndex, codingIndex, omniscience
Evals (0-1): """ + ", ".join(k for k, _, _ in EVALS) + """
Deep-only evals (model page): """ + ", ".join(k for k, _, _ in EVALS_DEEP) + """
Pricing ($/1M tok): price1mInputTokens, price1mOutputTokens, cacheHitPrice,
  cacheWritePrice, price1mBlended*, costPerTask (cache-aware, per AA task)
Speed: medianOutputTokensPerSecond (tps/throughput),
  medianTimeToFirstTokenSeconds (ttft/snappiness),
  medianTimeToFirstAnswerTokenSeconds, medianEndToEndResponseTimeSeconds,
  medianReasoningTimeSeconds, percentile05/95*, quartile25/75*
Provider endpoints (providers cmd): pricing.price1m*, cacheHitDiscountPercent,
  performance.outputSpeed/timeToFirstToken/endToEndResponseTime,
  intelligenceIndexCostPerTask, functionCalling, jsonMode, precision from slug
Identity: name, shortName, slug, modelCreatorName, releaseDate, isOpenWeights,
  licenseName, totalParameters, activeParameters, contextWindowTokens,
  isReasoning, deprecated, input/outputModality{Text,Image,Speech,Video}

NOT tracked by AA (do not guess — say AA has no data): MathVista, DocVQA,
BFCL/Berkeley function-calling. Vision = mmmuPro eval + modality flags;
tool-calling = functionCalling/jsonMode flags on provider endpoints.""")


# ---------------------------------------------------------------- entry point


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0],
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    lb = sub.add_parser("leaderboard", help="rank/filter all tracked models")
    lb.add_argument("--value", action="store_true", help="rank by intelligence per $")
    lb.add_argument("--frontier", action="store_true", help="Pareto frontier intel vs cost")
    lb.add_argument("--sort", choices=sorted(SORTS), default="intel",
                    help="tps=throughput tok/s, ttft=time-to-first-token (latency/speed are aliases)")
    lb.add_argument("--model", help="substring filter on model name")
    lb.add_argument("--creator", help="substring filter on creator or model family")
    lb.add_argument("--min-intel", type=float)
    lb.add_argument("--max-cost", type=float, help="max cost per task USD")
    lb.add_argument("--min-speed", type=float, help="min output tok/s")
    lb.add_argument("--open-weights", action="store_true")
    lb.add_argument("--reasoning", action=argparse.BooleanOptionalAction, default=None)
    lb.add_argument("--all", action="store_true",
                    help="include deprecated and unbenchmarked models (~600)")
    lb.add_argument("--compact", action="store_true",
                    help="only Model, Intel, $/Task, tok/s, Ctx")
    lb.add_argument("--fields", help="comma list of columns (run `fields` for names)")
    lb.add_argument("--top", type=int, default=20)
    lb.add_argument("--csv", help="also write table to CSV")
    lb.add_argument("--refresh", action="store_true")
    lb.set_defaults(fn=cmd_leaderboard)

    s = sub.add_parser("search", aliases=["list"],
                       help="list matching models + slugs (no ambiguity errors)")
    s.add_argument("query", nargs="?", default=None)
    s.add_argument("--creator", help="substring filter on creator or model family")
    s.add_argument("--open-weights", action="store_true")
    s.add_argument("--all", action="store_true", help="include deprecated")
    s.add_argument("--top", type=int, default=25)
    s.add_argument("--refresh", action="store_true")
    s.set_defaults(fn=cmd_search)

    m = sub.add_parser("model", help="full digest for one model (fuzzy name)")
    m.add_argument("query")
    m.add_argument("--refresh", action="store_true")
    m.set_defaults(fn=cmd_model)

    c = sub.add_parser("compare", help="side-by-side metrics for 2+ models")
    c.add_argument("queries", nargs="+")
    c.add_argument("--compact", action="store_true",
                   help="only Intel, $/Task, tok/s, TTFT, Context")
    c.add_argument("--fields", help="comma list of metric rows (run `fields` for names)")
    c.add_argument("--refresh", action="store_true")
    c.set_defaults(fn=cmd_compare)

    e = sub.add_parser("evals", help="benchmark scores (one model or one metric)")
    e.add_argument("query", nargs="?", default=None)
    e.add_argument("--metric", help="cross-model ranking on one benchmark (e.g. gpqa)")
    e.add_argument("--top", type=int, default=20)
    e.add_argument("--refresh", action="store_true")
    e.set_defaults(fn=cmd_evals)

    pr = sub.add_parser("providers", help="API providers for one model")
    pr.add_argument("query")
    pr.add_argument("--refresh", action="store_true")
    pr.set_defaults(fn=cmd_providers)

    pb = sub.add_parser("providers-board", help="global provider x model table")
    pb.add_argument("--model")
    pb.add_argument("--provider")
    pb.add_argument("--top", type=int, default=30)
    pb.add_argument("--refresh", action="store_true")
    pb.set_defaults(fn=cmd_providers_board)

    md = sub.add_parser("media", help="non-LLM leaderboards (image/video/speech)")
    md.add_argument("kind", choices=sorted(list(MEDIA) + list(SPEECH)))
    md.add_argument("--top", type=int, default=20)
    md.add_argument("--refresh", action="store_true")
    md.set_defaults(fn=cmd_media)

    j = sub.add_parser("json", help="raw JSON record(s), full precision")
    j.add_argument("query")
    j.add_argument("--deep", action="store_true", help="include model-page object")
    j.add_argument("--top", type=int, default=1)
    j.add_argument("--refresh", action="store_true")
    j.set_defaults(fn=cmd_json)

    f = sub.add_parser("fields", help="list all metric fields")
    f.set_defaults(fn=cmd_fields)

    a = p.parse_args()
    if getattr(a, "cmd", None) == "evals" and not a.metric and not a.query:
        p.error("evals needs a model query or --metric")
    a.fn(a)


if __name__ == "__main__":
    main()